# IMF_API
This repository contains the source code for the PyIMF Python package available in pip. With this package, users can navigate the IMF API documentation and request data in a very simple way.
